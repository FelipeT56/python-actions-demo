﻿namespace DNDMonsterManual
{
    partial class Form3
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.ListBox lstPinnedMonsters;
        private System.Windows.Forms.Button btnPin, btnUnpin, btnClearAll;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lstPinnedMonsters = new ListBox();
            btnPin = new Button();
            btnUnpin = new Button();
            btnClearAll = new Button();
            SuspendLayout();
            // 
            // lstPinnedMonsters
            // 
            lstPinnedMonsters.ItemHeight = 15;
            lstPinnedMonsters.Location = new Point(95, 39);
            lstPinnedMonsters.Name = "lstPinnedMonsters";
            lstPinnedMonsters.Size = new Size(312, 124);
            lstPinnedMonsters.TabIndex = 0;
            // 
            // btnPin
            // 
            btnPin.Location = new Point(192, 262);
            btnPin.Name = "btnPin";
            btnPin.Size = new Size(75, 23);
            btnPin.TabIndex = 1;
            btnPin.Text = "Pin";
            btnPin.Click += btnPin_Click;
            // 
            // btnUnpin
            // 
            btnUnpin.Location = new Point(282, 262);
            btnUnpin.Name = "btnUnpin";
            btnUnpin.Size = new Size(75, 23);
            btnUnpin.TabIndex = 2;
            btnUnpin.Text = "Unpin";
            btnUnpin.Click += btnUnpin_Click;
            // 
            // btnClearAll
            // 
            btnClearAll.Location = new Point(95, 262);
            btnClearAll.Name = "btnClearAll";
            btnClearAll.Size = new Size(75, 23);
            btnClearAll.TabIndex = 3;
            btnClearAll.Text = "Clear";
            btnClearAll.Click += btnClearAll_Click;
            // 
            // Form3
            // 
            ClientSize = new Size(500, 350);
            Controls.Add(lstPinnedMonsters);
            Controls.Add(btnPin);
            Controls.Add(btnUnpin);
            Controls.Add(btnClearAll);
            Name = "Form3";
            Text = "Pinned Monsters";
            ResumeLayout(false);
        }
    }
}
