﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace DNDMonsterManual
{
    public partial class Form3 : Form
    {
        private List<Monster> pinnedMonsters;

        public Form3()
        {
            InitializeComponent();
            pinnedMonsters = new List<Monster>();
            lstPinnedMonsters.DataSource = pinnedMonsters;
            lstPinnedMonsters.DisplayMember = "Name"; // Show monster name in ListBox
        }

        public void AddPinnedMonster(Monster monster)
        {
            pinnedMonsters.Add(monster);
            RefreshList();
        }

        private void btnUnpin_Click(object sender, EventArgs e)
        {
            if (lstPinnedMonsters.SelectedItem != null)
            {
                pinnedMonsters.Remove(lstPinnedMonsters.SelectedItem as Monster);
                RefreshList();
            }
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            pinnedMonsters.Clear();
            RefreshList();
        }
        private void btnPin_Click(object sender, EventArgs e)
        {
            if (lstPinnedMonsters.SelectedItem is Monster selected)
            {
                AddPinnedMonster(selected);
            }
        }

        private void RefreshList()
        {
            lstPinnedMonsters.DataSource = null;
            lstPinnedMonsters.DataSource = pinnedMonsters;
            lstPinnedMonsters.DisplayMember = "Name";
        }
    }
}
