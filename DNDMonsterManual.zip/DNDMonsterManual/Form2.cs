﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace DNDMonsterManual
{
    public partial class Form2 : Form
    {
        private DatabaseManager db;

        public Form2(DatabaseManager database)
        {
            InitializeComponent();
            db = database;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            LoadAllMonsters();
        }

        private void LoadAllMonsters()
        {
            List<Monster> monsters = db.GetAllMonsters();
            dgvMonsters.DataSource = monsters;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string query = txtSearch.Text.Trim();
            List<Monster> results = db.SearchMonsters(query);
            dgvMonsters.DataSource = results;
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadAllMonsters();
        }

        private void btnPinSelected_Click(object sender, EventArgs e)
        {
            if (dgvMonsters.CurrentRow != null)
            {
                Monster selected = dgvMonsters.CurrentRow.DataBoundItem as Monster;
                Form3 pinnedForm = new Form3();
                pinnedForm.AddPinnedMonster(selected); // Pass selected monster
                pinnedForm.Show();
            }
        }

        
    }
}
