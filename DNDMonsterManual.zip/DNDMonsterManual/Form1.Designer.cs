﻿namespace DNDMonsterManual
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox txtName;

        private System.Windows.Forms.Label lblSpecies;
        private System.Windows.Forms.TextBox txtSpecies;

        private System.Windows.Forms.Label lblCR;
        private System.Windows.Forms.TextBox txtCR;

        private System.Windows.Forms.Label lblAC;
        private System.Windows.Forms.TextBox txtAC;

        private System.Windows.Forms.Label lblSTR;
        private System.Windows.Forms.TextBox txtSTR;

        private System.Windows.Forms.Label lblDEX;
        private System.Windows.Forms.TextBox txtDEX;

        private System.Windows.Forms.Label lblCON;
        private System.Windows.Forms.TextBox txtCON;

        private System.Windows.Forms.Label lblINT;
        private System.Windows.Forms.TextBox txtINT;

        private System.Windows.Forms.Label lblWIS;
        private System.Windows.Forms.TextBox txtWIS;

        private System.Windows.Forms.Label lblCHA;
        private System.Windows.Forms.TextBox txtCHA;

        private System.Windows.Forms.Button btnSaveMonster;
        private System.Windows.Forms.Button btnOpenForm2;
        private System.Windows.Forms.Button btnOpenForm3;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblName = new Label();
            txtName = new TextBox();
            lblSpecies = new Label();
            txtSpecies = new TextBox();
            lblCR = new Label();
            txtCR = new TextBox();
            lblAC = new Label();
            txtAC = new TextBox();
            lblSTR = new Label();
            txtSTR = new TextBox();
            lblDEX = new Label();
            txtDEX = new TextBox();
            lblCON = new Label();
            txtCON = new TextBox();
            lblINT = new Label();
            txtINT = new TextBox();
            lblWIS = new Label();
            txtWIS = new TextBox();
            lblCHA = new Label();
            txtCHA = new TextBox();
            btnSaveMonster = new Button();
            btnOpenForm2 = new Button();
            btnOpenForm3 = new Button();
            SuspendLayout();
            // 
            // lblName
            // 
            lblName.Location = new Point(20, 63);
            lblName.Name = "lblName";
            lblName.Size = new Size(100, 23);
            lblName.TabIndex = 0;
            lblName.Text = "Name:";
            // 
            // txtName
            // 
            txtName.Location = new Point(120, 60);
            txtName.Name = "txtName";
            txtName.Size = new Size(150, 23);
            txtName.TabIndex = 1;
            
            // 
            // lblSpecies
            // 
            lblSpecies.Location = new Point(20, 95);
            lblSpecies.Name = "lblSpecies";
            lblSpecies.Size = new Size(100, 23);
            lblSpecies.TabIndex = 2;
            lblSpecies.Text = "Species:";
            // 
            // txtSpecies
            // 
            txtSpecies.Location = new Point(120, 95);
            txtSpecies.Name = "txtSpecies";
            txtSpecies.Size = new Size(150, 23);
            txtSpecies.TabIndex = 3;
            // 
            // lblCR
            // 
            lblCR.Location = new Point(20, 131);
            lblCR.Name = "lblCR";
            lblCR.Size = new Size(100, 23);
            lblCR.TabIndex = 4;
            lblCR.Text = "CR:";
            // 
            // txtCR
            // 
            txtCR.Location = new Point(120, 131);
            txtCR.Name = "txtCR";
            txtCR.Size = new Size(150, 23);
            txtCR.TabIndex = 5;
            // 
            // lblAC
            // 
            lblAC.Location = new Point(20, 167);
            lblAC.Name = "lblAC";
            lblAC.Size = new Size(100, 23);
            lblAC.TabIndex = 6;
            lblAC.Text = "AC:";
            // 
            // txtAC
            // 
            txtAC.Location = new Point(120, 167);
            txtAC.Name = "txtAC";
            txtAC.Size = new Size(150, 23);
            txtAC.TabIndex = 7;
            // 
            // lblSTR
            // 
            lblSTR.Location = new Point(20, 201);
            lblSTR.Name = "lblSTR";
            lblSTR.Size = new Size(100, 23);
            lblSTR.TabIndex = 8;
            lblSTR.Text = "STR:";
            // 
            // txtSTR
            // 
            txtSTR.Location = new Point(120, 201);
            txtSTR.Name = "txtSTR";
            txtSTR.Size = new Size(150, 23);
            txtSTR.TabIndex = 9;
            // 
            // lblDEX
            // 
            lblDEX.Location = new Point(20, 239);
            lblDEX.Name = "lblDEX";
            lblDEX.Size = new Size(100, 23);
            lblDEX.TabIndex = 10;
            lblDEX.Text = "DEX:";
            // 
            // txtDEX
            // 
            txtDEX.Location = new Point(120, 236);
            txtDEX.Name = "txtDEX";
            txtDEX.Size = new Size(150, 23);
            txtDEX.TabIndex = 11;
            // 
            // lblCON
            // 
            lblCON.Location = new Point(20, 274);
            lblCON.Name = "lblCON";
            lblCON.Size = new Size(100, 23);
            lblCON.TabIndex = 12;
            lblCON.Text = "CON:";
            // 
            // txtCON
            // 
            txtCON.Location = new Point(126, 271);
            txtCON.Name = "txtCON";
            txtCON.Size = new Size(150, 23);
            txtCON.TabIndex = 13;
            // 
            // lblINT
            // 
            lblINT.Location = new Point(20, 313);
            lblINT.Name = "lblINT";
            lblINT.Size = new Size(100, 23);
            lblINT.TabIndex = 14;
            lblINT.Text = "INT:";
            // 
            // txtINT
            // 
            txtINT.Location = new Point(120, 313);
            txtINT.Name = "txtINT";
            txtINT.Size = new Size(150, 23);
            txtINT.TabIndex = 15;
            // 
            // lblWIS
            // 
            lblWIS.Location = new Point(20, 357);
            lblWIS.Name = "lblWIS";
            lblWIS.Size = new Size(100, 23);
            lblWIS.TabIndex = 16;
            lblWIS.Text = "WIS:";
            // 
            // txtWIS
            // 
            txtWIS.Location = new Point(120, 354);
            txtWIS.Name = "txtWIS";
            txtWIS.Size = new Size(150, 23);
            txtWIS.TabIndex = 17;
            // 
            // lblCHA
            // 
            lblCHA.Location = new Point(20, 397);
            lblCHA.Name = "lblCHA";
            lblCHA.Size = new Size(100, 23);
            lblCHA.TabIndex = 18;
            lblCHA.Text = "CHA:";
            // 
            // txtCHA
            // 
            txtCHA.Location = new Point(120, 394);
            txtCHA.Name = "txtCHA";
            txtCHA.Size = new Size(150, 23);
            txtCHA.TabIndex = 19;
            // 
            // btnSaveMonster
            // 
            btnSaveMonster.Location = new Point(20, 444);
            btnSaveMonster.Name = "btnSaveMonster";
            btnSaveMonster.Size = new Size(75, 23);
            btnSaveMonster.TabIndex = 20;
            btnSaveMonster.Text = "Save Monster";
            btnSaveMonster.Click += btnSaveMonster_Click;
            // 
            // btnOpenForm2
            // 
            btnOpenForm2.Location = new Point(120, 444);
            btnOpenForm2.Name = "btnOpenForm2";
            btnOpenForm2.Size = new Size(75, 23);
            btnOpenForm2.TabIndex = 21;
            btnOpenForm2.Text = "View/Search Monsters";
            btnOpenForm2.Click += btnOpenForm2_Click;
            // 
            // btnOpenForm3
            // 
            btnOpenForm3.Location = new Point(221, 444);
            btnOpenForm3.Name = "btnOpenForm3";
            btnOpenForm3.Size = new Size(75, 23);
            btnOpenForm3.TabIndex = 22;
            btnOpenForm3.Text = "Pinned Monsters";
            btnOpenForm3.Click += btnOpenForm3_Click;
            // 
            // Form1
            // 
            ClientSize = new Size(350, 500);
            Controls.Add(lblName);
            Controls.Add(txtName);
            Controls.Add(lblSpecies);
            Controls.Add(txtSpecies);
            Controls.Add(lblCR);
            Controls.Add(txtCR);
            Controls.Add(lblAC);
            Controls.Add(txtAC);
            Controls.Add(lblSTR);
            Controls.Add(txtSTR);
            Controls.Add(lblDEX);
            Controls.Add(txtDEX);
            Controls.Add(lblCON);
            Controls.Add(txtCON);
            Controls.Add(lblINT);
            Controls.Add(txtINT);
            Controls.Add(lblWIS);
            Controls.Add(txtWIS);
            Controls.Add(lblCHA);
            Controls.Add(txtCHA);
            Controls.Add(btnSaveMonster);
            Controls.Add(btnOpenForm2);
            Controls.Add(btnOpenForm3);
            Name = "Form1";
            Text = "Monster Manual - Add Monster";
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
