using System;
using System.Windows.Forms;

namespace DNDMonsterManual
{
    public partial class Form1 : Form
    {
        private DatabaseManager db;

        public Form1()
        {
            InitializeComponent(); // Must call this first
            db = new DatabaseManager("monsters.db"); // Connect to SQLite database
        }

        // Save monster to database
        private void btnSaveMonster_Click(object sender, EventArgs e)
        {
            try
            {
                // Read input from TextBoxes
                string name = txtName.Text.Trim();
                string species = txtSpecies.Text.Trim();
                int cr = int.Parse(txtCR.Text);
                int ac = int.Parse(txtAC.Text);
                int str = int.Parse(txtSTR.Text);
                int dex = int.Parse(txtDEX.Text);
                int con = int.Parse(txtCON.Text);
                int intel = int.Parse(txtINT.Text);
                int wis = int.Parse(txtWIS.Text);
                int cha = int.Parse(txtCHA.Text);

                // Create Monster object
                Monster monster = new Monster(name, cr, ac, species, str, dex, con, intel, wis, cha);

                // Save to database
                db.AddMonster(monster);

                MessageBox.Show("Monster saved successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // Clear TextBoxes for next entry
                ClearForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving monster: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Open Form2 � View/Search Monsters
        private void btnOpenForm2_Click(object sender, EventArgs e)
        {
            Form2 viewForm = new Form2(db); // Pass same DatabaseManager instance
            viewForm.Show();
        }

        // Open Form3 � Pinned Monsters
        private void btnOpenForm3_Click(object sender, EventArgs e)
        {
            Form3 pinnedForm = new Form3();
            pinnedForm.Show();
        }

        // Clear all TextBoxes
        private void ClearForm()
        {
            txtName.Text = "";
            txtCR.Text = "";
            txtAC.Text = "";
            txtSpecies.Text = "";
            txtSTR.Text = "";
            txtDEX.Text = "";
            txtCON.Text = "";
            txtINT.Text = "";
            txtWIS.Text = "";
            txtCHA.Text = "";
        }

        
    }
}
