﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;

namespace DNDMonsterManual
{
    public class DatabaseManager
    {
        private string connectionString;

        public DatabaseManager(string dbFile)
        {
            if (!File.Exists(dbFile))
            {
                SQLiteConnection.CreateFile(dbFile);
            }

            connectionString = $"Data Source={dbFile};Version=3;";
            InitializeDatabase();
        }

        private void InitializeDatabase()
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sql = @"
                    CREATE TABLE IF NOT EXISTS Monsters (
                        Id INTEGER PRIMARY KEY AUTOINCREMENT,
                        Name TEXT NOT NULL,
                        CR INTEGER NOT NULL,
                        AC INTEGER NOT NULL,
                        Species TEXT NOT NULL,
                        STR INTEGER NOT NULL,
                        DEX INTEGER NOT NULL,
                        CON INTEGER NOT NULL,
                        INTEL INTEGER NOT NULL,
                        WIS INTEGER NOT NULL,
                        CHA INTEGER NOT NULL
                    );";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void AddMonster(Monster monster)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sql = @"
                    INSERT INTO Monsters (Name, CR, AC, Species, STR, DEX, CON, INTEL, WIS, CHA)
                    VALUES (@Name, @CR, @AC, @Species, @STR, @DEX, @CON, @INTEL, @WIS, @CHA);";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", monster.Name);
                    cmd.Parameters.AddWithValue("@CR", monster.ChallengeRating);
                    cmd.Parameters.AddWithValue("@AC", monster.ArmorClass);
                    cmd.Parameters.AddWithValue("@Species", monster.Species);
                    cmd.Parameters.AddWithValue("@STR", monster.Strength);
                    cmd.Parameters.AddWithValue("@DEX", monster.Dexterity);
                    cmd.Parameters.AddWithValue("@CON", monster.Constitution);
                    cmd.Parameters.AddWithValue("@INTEL", monster.Intelligence);
                    cmd.Parameters.AddWithValue("@WIS", monster.Wisdom);
                    cmd.Parameters.AddWithValue("@CHA", monster.Charisma);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Convert DataReader to List<Monster>
        private List<Monster> ReaderToList(SQLiteDataReader reader)
        {
            List<Monster> monsters = new List<Monster>();
            while (reader.Read())
            {
                Monster m = new Monster(
                    reader["Name"].ToString(),
                    Convert.ToInt32(reader["CR"]),
                    Convert.ToInt32(reader["AC"]),
                    reader["Species"].ToString(),
                    Convert.ToInt32(reader["STR"]),
                    Convert.ToInt32(reader["DEX"]),
                    Convert.ToInt32(reader["CON"]),
                    Convert.ToInt32(reader["INTEL"]),
                    Convert.ToInt32(reader["WIS"]),
                    Convert.ToInt32(reader["CHA"])
                );
                monsters.Add(m);
            }
            reader.Close();
            return monsters;
        }

        // Return all monsters as a list
        public List<Monster> GetAllMonsters()
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sql = "SELECT * FROM Monsters;";
                using (var cmd = new SQLiteCommand(sql, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    return ReaderToList(reader);
                }
            }
        }

        // Return search results as a list
        public List<Monster> SearchMonsters(string name)
        {
            using (var conn = new SQLiteConnection(connectionString))
            {
                conn.Open();
                string sql = "SELECT * FROM Monsters WHERE Name LIKE @Name;";
                using (var cmd = new SQLiteCommand(sql, conn))
                {
                    cmd.Parameters.AddWithValue("@Name", $"%{name}%");
                    using (var reader = cmd.ExecuteReader())
                    {
                        return ReaderToList(reader);
                    }
                }
            }
        }
    }
}
