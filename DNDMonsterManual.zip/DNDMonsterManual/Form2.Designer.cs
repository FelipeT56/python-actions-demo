﻿namespace DNDMonsterManual
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvMonsters;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Button btnSearch, btnRefresh, btnPinSelected;
        private System.Windows.Forms.Label lblSearch;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            lblSearch = new Label();
            txtSearch = new TextBox();
            btnSearch = new Button();
            btnRefresh = new Button();
            dgvMonsters = new DataGridView();
            btnPinSelected = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvMonsters).BeginInit();
            SuspendLayout();
            // 
            // lblSearch
            // 
            lblSearch.Location = new Point(73, 382);
            lblSearch.Name = "lblSearch";
            lblSearch.Size = new Size(100, 23);
            lblSearch.TabIndex = 0;
            lblSearch.Tag = "";
            lblSearch.Text = "Search:";
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(135, 379);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(188, 23);
            txtSearch.TabIndex = 1;
            // 
            // btnSearch
            // 
            btnSearch.Location = new Point(357, 378);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(75, 23);
            btnSearch.TabIndex = 2;
            btnSearch.Text = "Search";
            btnSearch.Click += btnSearch_Click;
            // 
            // btnRefresh
            // 
            btnRefresh.Location = new Point(513, 126);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(75, 23);
            btnRefresh.TabIndex = 3;
            btnRefresh.Text = "Refresh";
            btnRefresh.Click += btnRefresh_Click;
            // 
            // dgvMonsters
            // 
            dgvMonsters.Location = new Point(43, 45);
            dgvMonsters.Name = "dgvMonsters";
            dgvMonsters.Size = new Size(464, 327);
            dgvMonsters.TabIndex = 4;
            // 
            // btnPinSelected
            // 
            btnPinSelected.Location = new Point(513, 168);
            btnPinSelected.Name = "btnPinSelected";
            btnPinSelected.Size = new Size(75, 23);
            btnPinSelected.TabIndex = 5;
            btnPinSelected.Text = "Pin Monster";
            btnPinSelected.Click += btnPinSelected_Click;
            // 
            // Form2
            // 
            ClientSize = new Size(600, 420);
            Controls.Add(lblSearch);
            Controls.Add(txtSearch);
            Controls.Add(btnSearch);
            Controls.Add(btnRefresh);
            Controls.Add(dgvMonsters);
            Controls.Add(btnPinSelected);
            Name = "Form2";
            Text = "View Monsters";
            ((System.ComponentModel.ISupportInitialize)dgvMonsters).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }
    }
}
