﻿public class Monster
{
    public string Name { get; set; }
    public int ChallengeRating { get; set; }
    public int ArmorClass { get; set; }
    public string Species { get; set; }

    public int Strength { get; set; }
    public int Dexterity { get; set; }
    public int Constitution { get; set; }
    public int Intelligence { get; set; }
    public int Wisdom { get; set; }
    public int Charisma { get; set; }

    public Monster(string name, int cr, int ac, string species,
                   int str, int dex, int con, int intel, int wis, int cha)
    {
        Name = name;
        ChallengeRating = cr;
        ArmorClass = ac;
        Species = species;
        Strength = str;
        Dexterity = dex;
        Constitution = con;
        Intelligence = intel;
        Wisdom = wis;
        Charisma = cha;
    }
}
